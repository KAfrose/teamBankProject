export class AccountDetails {
    acc_number: string;
    custid: string;
    bid: string;
    balance: string;
    account_type: string;
}
