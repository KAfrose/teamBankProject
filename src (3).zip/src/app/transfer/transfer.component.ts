import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';

import { AccountDetails } from '../account-details';
import { Payee } from '../payee';
import { TransactionDetails } from '../transaction-details';

import { TransferService } from '../transfer.service';

@Component({
  selector: 'app-transfer',
  templateUrl: './transfer.component.html',
  styleUrls: ['./transfer.component.css']
})

export class TransferComponent implements OnInit {

    transferForm:any;
  constructor(private fb:FormBuilder, private ts:TransferService,private router:Router) { 
    this.transferForm=this.fb.group({
      acc_number:[''],
      payeeId:[''],
      dot:[''],
      transactionType:['online'],
      amount:[''], 
    });
  }

  ngOnInit(): void {
  }
  get form() {
    return this.transferForm.controls;
  }
  fnfundTransfer()
  {
    var transactiondetails=new TransactionDetails();
    var accountDetails:AccountDetails=new AccountDetails();
    var payee:Payee=new Payee();

    // transactiondetails.accountDetails=accountDetails;
    transactiondetails.accountDetails.acc_number=accountDetails.acc_number;

    // transactiondetails.payee=payee;
    transactiondetails.payee.payeeId=payee.payeeId;

    transactiondetails.dot=new Date();
    transactiondetails.amount=this.form.amount.value;
    
    //under construction
    this.ts.fundTransfer(transactiondetails).subscribe(data=>{
      console.log(data);
    });
  }
    
        
  

}
