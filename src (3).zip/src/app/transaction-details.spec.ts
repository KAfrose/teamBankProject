import { TransactionDetails } from './transaction-details';

describe('TransactionDetails', () => {
  it('should create an instance', () => {
    expect(new TransactionDetails()).toBeTruthy();
  });
});
