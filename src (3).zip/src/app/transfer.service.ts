import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TransferService {
  url:string='http://localhost:8080/transactiondetails/';
  constructor(private http:HttpClient) {

    
   }
   fundTransfer(transactiondetails:any)
  {
    return this.http.post(this.url,transactiondetails);
  }
  
}
