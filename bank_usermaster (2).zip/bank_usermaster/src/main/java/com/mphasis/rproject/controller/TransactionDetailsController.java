package com.mphasis.rproject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.rproject.entity.AccountDetails;
import com.mphasis.rproject.entity.TransactionDetails;
import com.mphasis.rproject.model.AccountDetailsService;
import com.mphasis.rproject.model.TransactionDetailsService;

@RestController
@CrossOrigin(origins = {"http://localhost:4200", "*"})
@RequestMapping("/transactiondetails")
public class TransactionDetailsController {
	@Autowired
	TransactionDetailsService ts;
	
	@Autowired
	AccountDetailsService as;
	
	
	 //@PostMapping("/fundstransfer")
	 
	 
	@GetMapping("/")
	public List<TransactionDetails> getAllTransactions()
	{
		//display all acc_details
		List<TransactionDetails> acds = ts.read();
		return acds;
	}
	
//	@GetMapping("/{transaction_id}")			
//	public TransactionDetails findAccountByAcN(@PathVariable("transaction_id") String transaction_id)
//	{
//		return ts.read(transaction_id);
//	}
	
	@PostMapping("/")
	public TransactionDetails  fundTransfer(@RequestBody TransactionDetails td)
	{
		//add a row to the transaction table
		//update the balance in the account table
		AccountDetails ad = td.getAccountDetails();
		String balance = ad.getBalance();
		Double b=Double.parseDouble(balance);
		String tamount = td.getAmount();
		Double amt=Double.parseDouble(tamount);
		if(amt>b)
			throw new NumberFormatException("Amount is greater than the balance");
		b-=amt;
		ad.setBalance(b+"");
		return ts.create(td);
	}
	
	@PutMapping("/")
	public TransactionDetails  modifyBranch(@RequestBody TransactionDetails  ad)
	{
		return ts.update(ad);
	}
	
//	@DeleteMapping("/{transaction_id}")
//	public void deleteBranch(@PathVariable("transaction_id") Long transaction_id)
//	{
//		ts.delete(transaction_id);
//	}


}

	

